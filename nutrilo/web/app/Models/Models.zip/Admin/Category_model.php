<?php namespace App\Models\Admin;
use CodeIgniter\Model;
 
class Category_model extends Model
{
    protected $table = 'category';
     
    public function getCategory($id = false)
    {
        if($id === false){
            return $this->findAll();
        }else{
            return $this->getWhere(['id' => $id]);
        }   
    }

}