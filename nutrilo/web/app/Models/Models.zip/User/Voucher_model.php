<?php namespace App\Models\User;
use CodeIgniter\Model;
 
class Voucher_model extends Model
{
    protected $table = 'voucher';
     
    public function getVoucher($id = false)
    {
        if($id === false){
            return $this->findAll();
        }else{
            return $this->getWhere(['id' => $id]);
        }   
    }

    public function getVoucherByCode($code) {
        return $this->getWhere(['code' => $code, 'is_deleted' => false]);
    }

}